<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "project01");

if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: " . $mysqli->connect_error);
}

// Check logged in user
if (!isset($_SESSION['user_id'])) {
    // Redirect to login if not logged in
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

// Validate POST data
if (
    !isset($_POST['products'], $_POST['quantities'], $_POST['prices'], $_POST['total']) ||
    !is_array($_POST['products']) || !is_array($_POST['quantities']) || !is_array($_POST['prices'])
) {
    die("Invalid input.");
}

$products = $_POST['products'];
$quantities = $_POST['quantities'];
$prices = $_POST['prices'];
$total = floatval($_POST['total']);

if (count($products) === 0) {
    die("No products selected.");
}

// Start transaction
$mysqli->begin_transaction();

try {
    // Insert sale record
    $stmt = $mysqli->prepare("INSERT INTO sales (user_id, sale_date, total) VALUES (?, NOW(), ?)");
    $stmt->bind_param("id", $user_id, $total);
    $stmt->execute();
    $sale_id = $stmt->insert_id;
    $stmt->close();

    // Prepare sale_details insert
    $stmtDetail = $mysqli->prepare("INSERT INTO sales_details (sale_id, product_id, quantity, selling_price) VALUES (?, ?, ?, ?)");

    // Update product stock statement
    $stmtStock = $mysqli->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");

    for ($i = 0; $i < count($products); $i++) {
        $prod_id = intval($products[$i]);
        $qty = intval($quantities[$i]);
        $price = floatval($prices[$i]);

        // Check stock availability and update
        $stmtStock->bind_param("iii", $qty, $prod_id, $qty);
        $stmtStock->execute();

        if ($stmtStock->affected_rows === 0) {
            throw new Exception("Insufficient stock for product ID $prod_id.");
        }

        // Insert into sales_details
        $stmtDetail->bind_param("iiid", $sale_id, $prod_id, $qty, $price);
        $stmtDetail->execute();
    }

    $stmtDetail->close();
    $stmtStock->close();

    $mysqli->commit();

    // Redirect with success and sale_id for receipt
    header("Location: cashier.php?success=1&sale_id=" . $sale_id);
    exit;

} catch (Exception $e) {
    $mysqli->rollback();
    die("Sale failed: " . $e->getMessage());
}
?>