<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'cashier') {
    header("Location: login.php");
    exit;
}
$username = $_SESSION['username'];
$current = basename($_SERVER['PHP_SELF']);

$mysqli = new mysqli("localhost", "root", "", "project01"); 

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch products
$product_result = $mysqli->query("SELECT id, name, stock, price FROM products ORDER BY name ASC");
$products = [];
if ($product_result) {
    while ($row = $product_result->fetch_assoc()) {
        $products[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cashier - Sales</title>
    <?php if (isset($_GET['success'])): ?>
        <meta http-equiv="refresh";url=cashier.php">
    <?php endif; ?>
</head>
<body>

<h2>Cashier - New Sale</h2>


<?php if (isset($_GET['success']) && isset($_GET['sale_id'])): ?>
    <div>
        <h3>Sale Successful!</h3>
        <p>Sale ID: <?= htmlspecialchars($_GET['sale_id']) ?></p>
        <button onclick="window.print()">Print Receipt</button>
    </div>
    <hr>
<?php endif; ?>

<form method="POST" action="process_sale.php" id="saleForm">
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Available</th>
                <th>Qty</th>
                <th>Price</th>
                <th></th>
            </tr>
        </thead>
        <tbody id="sale-items">
            <tr>
                <td>
                    <select name="products[]" required>
                        <option value="">Select</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?= $product['id'] ?>"
                                data-stock="<?= $product['stock'] ?>"
                                data-price="<?= $product['price'] ?>">
                                <?= htmlspecialchars($product['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td class="stock-display">0</td>
                <td><input type="number" name="quantities[]" min="1" value="1" required></td>
                <td><input type="number" name="prices[]" step="0.01" required></td>
                <td><button type="button" onclick="removeRow(this)">Remove</button></td>
            </tr>
        </tbody>
    </table>

    <button type="button" onclick="addRow()">Add Product</button><br><br>
    <label>Total ₱: <input type="number" name="total" id="sale-total" step="0.01" readonly required></label><br><br>
    <input type="submit" value="Save Sale">
</form>
<?php
if (isset($_GET['success']) && isset($_GET['sale_id'])):
    $sale_id = intval($_GET['sale_id']);
    // Fetch sale info
    $sale_stmt = $mysqli->prepare("SELECT s.id, s.sale_date, s.total, u.username FROM sales s LEFT JOIN users u ON s.user_id = u.id WHERE s.id = ?");
    $sale_stmt->bind_param("i", $sale_id);
    $sale_stmt->execute();
    $sale_result = $sale_stmt->get_result();
    $sale = $sale_result->fetch_assoc();
    $sale_stmt->close();

    // Fetch sale details
    $details_stmt = $mysqli->prepare("SELECT sd.quantity, sd.selling_price, p.name FROM sales_details sd LEFT JOIN products p ON sd.product_id = p.id WHERE sd.sale_id = ?");
    $details_stmt->bind_param("i", $sale_id);
    $details_stmt->execute();
    $details_result = $details_stmt->get_result();
    $details = [];
    while ($row = $details_result->fetch_assoc()) {
        $details[] = $row;
    }
    $details_stmt->close();
?>
<div id="receipt-area" style="max-width:400px;margin:30px auto;padding:20px;border:1px solid #ccc;background:#fff;">
    <h3 style="text-align:center;">Mia's Kape</h3>
    <p><strong>Sale ID:</strong> <?= htmlspecialchars($sale['id']) ?></p>
    <p><strong>Cashier:</strong> <?= htmlspecialchars($sale['username']) ?></p>
    <p><strong>Date:</strong> <?= htmlspecialchars($sale['sale_date']) ?></p>
    <table border="1" cellpadding="5" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Product</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($details as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td>₱<?= number_format($item['selling_price'], 2) ?></td>
                <td>₱<?= number_format($item['quantity'] * $item['selling_price'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <p style="text-align:right;"><strong>Total:</strong> ₱<?= number_format($sale['total'], 2) ?></p>
</div>
<div style="text-align:center;">
    <button onclick="printReceipt()">Print Receipt</button>
    <a href="cashier.php" class="btn-cancel">New Sale</a>
</div>
<script>
function printReceipt() {
    var printContents = document.getElementById('receipt-area').innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    window.location.href = 'cashier.php';
}
</script>
<hr>
<?php endif; ?>
  <script src="./assets/js/cashier.js"></script>

</body>
</html>
