
function addRow() {
    const row = document.querySelector('#sale-items tr').cloneNode(true);
    row.querySelectorAll('input').forEach(input => input.value = '');
    row.querySelector('select').selectedIndex = 0;
    row.querySelector('.stock-display').innerText = '0';
    document.getElementById('sale-items').appendChild(row);
}

function removeRow(button) {
    const rows = document.querySelectorAll('#sale-items tr');
    if (rows.length > 1) {
        button.closest('tr').remove();
        calculateTotal();
    }
}

// Update stock and price when product changes
document.addEventListener('change', function(e) {
    if (e.target.tagName === 'SELECT' && e.target.name === 'products[]') {
        const selectedOption = e.target.options[e.target.selectedIndex];
        const stock = selectedOption.dataset.stock;
        const price = selectedOption.dataset.price;

        const row = e.target.closest('tr');
        row.querySelector('.stock-display').innerText = stock;
        row.querySelector('input[name="prices[]"]').value = price;

        calculateTotal();
    }
});

// Recalculate total on quantity or price input change
document.getElementById('sale-items').addEventListener('input', function(e) {
    if (e.target.name === 'quantities[]' || e.target.name === 'prices[]') {
        calculateTotal();
    }
});

function calculateTotal() {
    let total = 0;
    const rows = document.querySelectorAll('#sale-items tr');
    rows.forEach(row => {
        const qtyInput = row.querySelector('input[name="quantities[]"]');
        const priceInput = row.querySelector('input[name="prices[]"]');
        const qty = parseFloat(qtyInput.value) || 0;
        const price = parseFloat(priceInput.value) || 0;
        total += qty * price;
    });
    document.getElementById('sale-total').value = total.toFixed(2);
}

// Initialize total on page load
calculateTotal();