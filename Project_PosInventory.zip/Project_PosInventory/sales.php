<?php
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
}
$username = $_SESSION['username'];
$current = basename($_SERVER['PHP_SELF']);

// Connect to DB
$mysqli = new mysqli("localhost", "root", "", "project01");
if ($mysqli->connect_errno) {
    die("Failed to connect to MySQL: " . $mysqli->connect_error);
}

// Fetch all sales with user info
$sales = [];
$result = $mysqli->query("SELECT sales.id, users.username, sales.sale_date, sales.total 
                          FROM sales 
                          LEFT JOIN users ON sales.user_id = users.id 
                          ORDER BY sales.sale_date DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $sales[] = $row;
    }
}

// Fetch sale details if a sale is selected
$sale_details = [];
if (isset($_GET['sale_id'])) {
    $sale_id = intval($_GET['sale_id']);
    $stmt = $mysqli->prepare("SELECT sd.*, p.name AS product_name 
                              FROM sales_details sd 
                              LEFT JOIN products p ON sd.product_id = p.id 
                              WHERE sd.sale_id = ?");
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sale_details[] = $row;
    }
    $stmt->close();
}
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Sales - Mia's Kape</title>
  <link rel="stylesheet" href="/Project_PosInventory/assets/style.css">
</head>
<body>
  <div class="dashboard">
    <aside class="sidebar">
      <h2 class="brand"> Mia's Kape</h2>
      <nav class="nav-links">
        <a href="admin.php" class="<?= $current === 'admin.php' ? 'active' : '' ?>">Dashboard</a>
        <a href="user_management.php" class="<?= $current === 'user_management.php' ? 'active' : '' ?>">Users</a>
        <a href="products.php" class="<?= $current === 'products.php' ? 'active' : '' ?>">Products</a>
        <a href="suppliers.php" class="<?= $current === 'suppliers.php' ? 'active' : '' ?>">Suppliers</a>
        <a href="purchases.php" class="<?= $current === 'purchases.php' ? 'active' : '' ?>">Purchases</a>
        <a href="sales.php" class="<?= $current === 'sales.php' ? 'active' : '' ?>">Sales</a>
        <a href="returns.php" class="<?= $current === 'returns.php' ? 'active' : '' ?>">Returns</a>
      </nav>
    </aside>
    <main class="main-content">
      <header class="topbar">
        <div class="admin-actions">
          <button id="adminButton"><?= htmlspecialchars($username) ?> ▾</button>
          <div class="dropdown hidden" id="adminDropdown">
            <a href="logout.php">Logout</a>
          </div>
        </div>
      </header>
      <section class="content">
        <div class="sales-header">
          <h2>Sales</h2>
        </div>
        <table class="sales-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Cashier</th>
              <th>Date</th>
              <th>Total</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($sales as $sale): ?>
              <tr>
                <td><?= $sale['id'] ?></td>
                <td><?= htmlspecialchars($sale['username']) ?></td>
                <td><?= htmlspecialchars($sale['sale_date']) ?></td>
                <td>₱<?= number_format($sale['total'], 2) ?></td>
                <td>
                  <a href="sales.php?sale_id=<?= $sale['id'] ?>" class="btn-details">View</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <?php if (!empty($sale_details)): ?>
        <div class="sale-details-modal modal" style="display:block;">
          <div class="modal-content">
            <span class="close" onclick="window.location='sales.php'">&times;</span>
            <h3>Sale Details (Sale #<?= htmlspecialchars($_GET['sale_id']) ?>)</h3>
            <table class="sale-details-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Quantity</th>
                  <th>Selling Price</th>
                  <th>Subtotal</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($sale_details as $detail): ?>
                  <tr>
                    <td><?= htmlspecialchars($detail['product_name']) ?></td>
                    <td><?= $detail['quantity'] ?></td>
                    <td>₱<?= number_format($detail['selling_price'], 2) ?></td>
                    <td>₱<?= number_format($detail['quantity'] * $detail['selling_price'], 2) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <div style="text-align:right; margin-top:10px;">
              <a href="sales.php" class="btn-cancel">Close</a>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </section>
    </main>
  </div>
      <script>
    document.getElementById('adminButton').addEventListener('click', function() {
      document.getElementById('adminDropdown').classList.toggle('hidden');
    });
  </script>
</body>
</html>